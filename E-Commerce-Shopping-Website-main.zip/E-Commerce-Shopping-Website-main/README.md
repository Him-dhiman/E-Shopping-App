# E-Commerce-Shopping-Website
Steps to download
1. First download all the files 
2. Make sure that you shoud all the files in a same folder
3. Just open the 'index.html' file to access the website
4. Please note that this website is only for PC not for mobile phones.
